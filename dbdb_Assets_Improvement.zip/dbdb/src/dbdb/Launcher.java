package dbdb;


public class Launcher {

    
    public static void main(String[] args)throws Exception {
        Game g = new Game("Pokemon",800,600);
        g.start();
    }
    
}
