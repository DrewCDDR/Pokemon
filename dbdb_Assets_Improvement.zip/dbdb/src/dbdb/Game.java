package dbdb;

import Visual.Assets;
import Visual.ImageLoader;
import Visual.SpriteSheet;
import Visual.Window;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;


public class Game implements Runnable{
    private boolean running = false;

    private Window display;
    
    public int width, height;
    public String title;
    
    private Thread thread;
    
    private BufferStrategy bs;
    private Graphics g;
    
    
    public Game(String title, int width, int height) {
        this.width = width;
        this.height = height;
        this.title = title;  
    }
    
    private void init(){
        display = new Window(title,width,height);
        Assets.init();
    }
    
    private void update(){
        
    }
    
    private void render(){
        bs = display.getCanvas().getBufferStrategy();
        if (bs == null) {
           display.getCanvas().createBufferStrategy(3);
           return;
        }
        g = bs.getDrawGraphics();
        //clear window
        g.clearRect(0, 0, width, height);
        //start drawing
        
        g.drawImage((Assets.dirt).getScaledInstance(32, 32, 0), 0, 16, null);
        g.drawImage(Assets.player, 0, 0, null);
        
        //end drawing
        bs.show();
        g.dispose();
        
    }
    
    public void run(){
        init();
        
        while(running){
            update();
            render();
        }
        stop();
    }
    
    public synchronized void start(){
        if(running)return;
        running = true;
        thread = new Thread(this);
        thread.start();
    }
    
    public synchronized void stop(){
        if(!running)return;
        running = false;
        try{
            thread.join();
        }catch(InterruptedException e){
            e.printStackTrace();
        }
    }
}
