package Classes;

public class Pokemon {
    
    private int id;
    private int hp;
    private int att;
    private int def;
    private int spd;
    private int attSp;
    private int defSp;
    private int catchR;
    private int xp=0;
    private int happ;
    private int effHp;
    private int effAtt;
    private int effDef;
    private int effSpd;
    private int effAttSp;
    private int effDefSpp;
    private int height;
    private int weight;
    private int genderR;
    private int evLvl;
    private String name;
    private String iName;
    private String kind;
    private String pInfo;
    private String type1;
    private String type2;
    
    private String growR;
    private String StepsTH;
    private String color;
    private String habitat;
    
    private String ab;
    private String hAb;
    private String itC;
    private String itR;
    private String comp;
    private String[] moves;
    private String[] allMoves;
    private String ev;

    public Pokemon(int id, int hp, int att, int def, int spd, int attSp,
            int defSp, int catchR, int happ, int effHp, int effAtt, int effDef,
            int effSpd, int effAttSp, int effDefSpp, int height, int weight,
            int genderR, int evLvl, String name, String iName, String kind,
            String pInfo, String type1, String type2, String growR,
            String StepsTH, String color, String habitat, String ab, String hAb,
            String itC, String itR, String comp, String ev) {
        
        this.id = id;
        this.hp = hp;
        this.att = att;
        this.def = def;
        this.spd = spd;
        this.attSp = attSp;
        this.defSp = defSp;
        this.catchR = catchR;
        this.happ = happ;
        this.effHp = effHp;
        this.effAtt = effAtt;
        this.effDef = effDef;
        this.effSpd = effSpd;
        this.effAttSp = effAttSp;
        this.effDefSpp = effDefSpp;
        this.height = height;
        this.weight = weight;
        this.genderR = genderR;
        this.evLvl = evLvl;
        this.name = name;
        this.iName = iName;
        this.kind = kind;
        this.pInfo = pInfo;
        this.type1 = type1;
        this.type2 = type2;
        this.growR = growR;
        this.StepsTH = StepsTH;
        this.color = color;
        this.habitat = habitat;
        this.ab = ab;
        this.hAb = hAb;
        this.itC = itC;
        this.itR = itR;
        this.comp = comp;
        this.ev = ev;
    }
    
    

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the hp
     */
    public int getHp() {
        return hp;
    }

    /**
     * @param hp the hp to set
     */
    public void setHp(int hp) {
        this.hp = hp;
    }

    /**
     * @return the att
     */
    public int getAtt() {
        return att;
    }

    /**
     * @param att the att to set
     */
    public void setAtt(int att) {
        this.att = att;
    }

    /**
     * @return the def
     */
    public int getDef() {
        return def;
    }

    /**
     * @param def the def to set
     */
    public void setDef(int def) {
        this.def = def;
    }

    /**
     * @return the spd
     */
    public int getSpd() {
        return spd;
    }

    /**
     * @param spd the spd to set
     */
    public void setSpd(int spd) {
        this.spd = spd;
    }

    /**
     * @return the attSp
     */
    public int getAttSp() {
        return attSp;
    }

    /**
     * @param attSp the attSp to set
     */
    public void setAttSp(int attSp) {
        this.attSp = attSp;
    }

    /**
     * @return the defSp
     */
    public int getDefSp() {
        return defSp;
    }

    /**
     * @param defSp the defSp to set
     */
    public void setDefSp(int defSp) {
        this.defSp = defSp;
    }

    /**
     * @return the catchR
     */
    public int getCatchR() {
        return catchR;
    }

    /**
     * @param catchR the catchR to set
     */
    public void setCatchR(int catchR) {
        this.catchR = catchR;
    }

    /**
     * @return the xp
     */
    public int getXp() {
        return xp;
    }

    /**
     * @param xp the xp to set
     */
    public void setXp(int xp) {
        this.xp = xp;
    }

    /**
     * @return the happ
     */
    public int getHapp() {
        return happ;
    }

    /**
     * @param happ the happ to set
     */
    public void setHapp(int happ) {
        this.happ = happ;
    }

    /**
     * @return the effHp
     */
    public int getEffHp() {
        return effHp;
    }

    /**
     * @param effHp the effHp to set
     */
    public void setEffHp(int effHp) {
        this.effHp = effHp;
    }

    /**
     * @return the effAtt
     */
    public int getEffAtt() {
        return effAtt;
    }

    /**
     * @param effAtt the effAtt to set
     */
    public void setEffAtt(int effAtt) {
        this.effAtt = effAtt;
    }

    /**
     * @return the effDef
     */
    public int getEffDef() {
        return effDef;
    }

    /**
     * @param effDef the effDef to set
     */
    public void setEffDef(int effDef) {
        this.effDef = effDef;
    }

    /**
     * @return the effSpd
     */
    public int getEffSpd() {
        return effSpd;
    }

    /**
     * @param effSpd the effSpd to set
     */
    public void setEffSpd(int effSpd) {
        this.effSpd = effSpd;
    }

    /**
     * @return the effAttSp
     */
    public int getEffAttSp() {
        return effAttSp;
    }

    /**
     * @param effAttSp the effAttSp to set
     */
    public void setEffAttSp(int effAttSp) {
        this.effAttSp = effAttSp;
    }

    /**
     * @return the effDefSpp
     */
    public int getEffDefSpp() {
        return effDefSpp;
    }

    /**
     * @param effDefSpp the effDefSpp to set
     */
    public void setEffDefSpp(int effDefSpp) {
        this.effDefSpp = effDefSpp;
    }

    /**
     * @return the height
     */
    public int getHeight() {
        return height;
    }

    /**
     * @param height the height to set
     */
    public void setHeight(int height) {
        this.height = height;
    }

    /**
     * @return the weight
     */
    public int getWeight() {
        return weight;
    }

    /**
     * @param weight the weight to set
     */
    public void setWeight(int weight) {
        this.weight = weight;
    }

    /**
     * @return the genderR
     */
    public int getGenderR() {
        return genderR;
    }

    /**
     * @param genderR the genderR to set
     */
    public void setGenderR(int genderR) {
        this.genderR = genderR;
    }

    /**
     * @return the evLvl
     */
    public int getEvLvl() {
        return evLvl;
    }

    /**
     * @param evLvl the evLvl to set
     */
    public void setEvLvl(int evLvl) {
        this.evLvl = evLvl;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the iName
     */
    public String getiName() {
        return iName;
    }

    /**
     * @param iName the iName to set
     */
    public void setiName(String iName) {
        this.iName = iName;
    }

    /**
     * @return the kind
     */
    public String getKind() {
        return kind;
    }

    /**
     * @param kind the kind to set
     */
    public void setKind(String kind) {
        this.kind = kind;
    }

    /**
     * @return the pInfo
     */
    public String getpInfo() {
        return pInfo;
    }

    /**
     * @param pInfo the pInfo to set
     */
    public void setpInfo(String pInfo) {
        this.pInfo = pInfo;
    }

    /**
     * @return the type1
     */
    public String getType1() {
        return type1;
    }

    /**
     * @param type1 the type1 to set
     */
    public void setType1(String type1) {
        this.type1 = type1;
    }

    /**
     * @return the type2
     */
    public String getType2() {
        return type2;
    }

    /**
     * @param type2 the type2 to set
     */
    public void setType2(String type2) {
        this.type2 = type2;
    }

    /**
     * @return the growR
     */
    public String getGrowR() {
        return growR;
    }

    /**
     * @param growR the growR to set
     */
    public void setGrowR(String growR) {
        this.growR = growR;
    }

    /**
     * @return the StepsTH
     */
    public String getStepsTH() {
        return StepsTH;
    }

    /**
     * @param StepsTH the StepsTH to set
     */
    public void setStepsTH(String StepsTH) {
        this.StepsTH = StepsTH;
    }

    /**
     * @return the color
     */
    public String getColor() {
        return color;
    }

    /**
     * @param color the color to set
     */
    public void setColor(String color) {
        this.color = color;
    }

    /**
     * @return the habitat
     */
    public String getHabitat() {
        return habitat;
    }

    /**
     * @param habitat the habitat to set
     */
    public void setHabitat(String habitat) {
        this.habitat = habitat;
    }

    /**
     * @return the ab
     */
    public String getAb() {
        return ab;
    }

    /**
     * @param ab the ab to set
     */
    public void setAb(String ab) {
        this.ab = ab;
    }

    /**
     * @return the hAb
     */
    public String gethAb() {
        return hAb;
    }

    /**
     * @param hAb the hAb to set
     */
    public void sethAb(String hAb) {
        this.hAb = hAb;
    }

    /**
     * @return the itC
     */
    public String getItC() {
        return itC;
    }

    /**
     * @param itC the itC to set
     */
    public void setItC(String itC) {
        this.itC = itC;
    }

    /**
     * @return the itR
     */
    public String getItR() {
        return itR;
    }

    /**
     * @param itR the itR to set
     */
    public void setItR(String itR) {
        this.itR = itR;
    }

    /**
     * @return the comp
     */
    public String getComp() {
        return comp;
    }

    /**
     * @param comp the comp to set
     */
    public void setComp(String comp) {
        this.comp = comp;
    }

    /**
     * @return the moves
     */
    public String[] getMoves() {
        return moves;
    }

    /**
     * @param moves the moves to set
     */
    public void setMoves(String[] moves)  {
        this.setMoves(moves);
    }

    /**
     * @return the ev
     */
    public String getEv() {
        return ev;
    }

    /**
     * @param ev the ev to set
     */
    public void setEv(String ev) {
        this.ev = ev;
    }
    
    /**
     * @return the allMoves
     */
    public String[] getAllMoves() {
        return allMoves;
    }

    /**
     * @param allMoves the allMoves to set
     */
    public void setAllMoves(String[] allMoves) {
        this.allMoves = allMoves;
    }
    
    
    
}


