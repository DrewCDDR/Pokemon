package Visual;

import java.awt.Canvas;



public class Map extends Canvas {

   
    
}
