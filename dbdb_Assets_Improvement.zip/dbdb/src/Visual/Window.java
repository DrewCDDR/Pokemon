/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Visual;

import java.awt.Canvas;
import java.awt.Dimension;
//import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
//import java.awt.image.BufferStrategy;
import java.io.File;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author Daffy
 */
public class Window implements WindowListener,
        ActionListener{
    
    private JFrame ventana;
    private Canvas canvas;
    //
    
    private int width,height;
    private String title;
    public static int counter = 0;
    
    
    String a;
    String[] s1;
    String[] s2;
    String[] s3 = new String[29];
    public boolean sw = false;
    public int rand;
    public ImageIcon icon;
    public JLabel pokemonImage = new JLabel();
    JLabel JLname = new JLabel();

    public Window(String title, int width, int height){
        this.title = title;
        this.width = width;
        this.height = height;
        
        newDisplay();
    }
    
    public void newDisplay(){
        ventana = new JFrame(title);
        ventana.setSize(width,height);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setResizable(false);
        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);
        
        canvas = new Canvas();
        canvas.setPreferredSize(new Dimension(width,height));
        canvas.setMinimumSize(new Dimension(width,height));
        canvas.setMaximumSize(new Dimension(width,height));
        
        ventana.add(canvas);
        ventana.pack();
    }
    
    public Canvas getCanvas(){
        return canvas;
    }
    
    public static int rand(int min, int max){
        Random rand = new Random();
        int randNum = rand.nextInt((max - min) + 1) + min;
        return randNum;
    }
    
    public void readPokemon(int id) throws Exception{
        int counter = 1;
        String idS = Integer.toString(id);
        
        File file = new File("txt/pokemon.txt");
        Scanner pokemon = new Scanner(file);

        while(pokemon.hasNextLine() && sw == false){
            String line = pokemon.nextLine();
            s1 = line.split("\\|");
            s2 = s1[0].split("=");
            if (s2[1].equals(idS)) {
                break;
            }
        }
         for (int i = 0; i < 22; i++) {
             s2 = s1[i].split("=");
             s3[i] = s2[1];
             System.out.println(s2[1]);
             System.out.println(s3[i]);
         }
         

    
    }

    @Override
    public void windowOpened(WindowEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); 
        
    }

    @Override
    public void windowClosing(WindowEvent e) {
        throw new UnsupportedOperationException("Not supported yet.");
        //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void windowClosed(WindowEvent e) {
        throw new UnsupportedOperationException("Not supported yet.");
        //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void windowIconified(WindowEvent e) {
        throw new UnsupportedOperationException("Not supported yet.");
        //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void windowDeiconified(WindowEvent e) {
        throw new UnsupportedOperationException("Not supported yet.");
        //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void windowActivated(WindowEvent e) {
        throw new UnsupportedOperationException("Not supported yet.");
        //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void windowDeactivated(WindowEvent e) {
        throw new UnsupportedOperationException("Not supported yet.");
        //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        int id = rand(1,151);
        try {
            readPokemon(id);
        } catch (Exception ex) {
            Logger.getLogger(Window.class.getName()).log(Level.SEVERE, null, ex);
        }
        icon = new ImageIcon("Shinys/Front/"+id+".gif");
        pokemonImage.setIcon(icon);
        JLname.setText("name: "+ s3[1]);
        JLname.setVisible(true);
        
        
    }
    
    
    
    
    
    
}
