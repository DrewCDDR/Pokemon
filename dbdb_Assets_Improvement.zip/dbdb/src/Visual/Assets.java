package Visual;

import java.awt.image.BufferedImage;


public class Assets {
    private static final int pWidht=32,pHeight=48;
    private static final int tileWidht = 16, tileHeight = 16;
    
    public static BufferedImage player,grass,dirt,water;
    
    public static void init(){
        SpriteSheet pSheet =
                new SpriteSheet(ImageLoader.loadImage("/Character/Walk.png"));
        SpriteSheet tileSheet =
                new SpriteSheet(ImageLoader.loadImage("/Tilesets/Dirt.png"));
        
        player = pSheet.cut(0,48,pWidht,pHeight);
        dirt = tileSheet.cut(0,0,tileWidht,tileHeight);
                
    }
}
